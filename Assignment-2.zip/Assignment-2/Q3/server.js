import express from "express";
import session from "express-session";
import connectRedis from "connect-redis";
import Redis from "ioredis";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const RedisStore = connectRedis(session);
const redisClient = new Redis(process.env.REDIS_URL || "redis://127.0.0.1:6379");

const app = express();
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(express.urlencoded({ extended: true }));

app.use(session({
  store: new RedisStore({ client: redisClient }),
  secret: "redis-secret",
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 1000 * 60 * 15 }
}));

const USERS = [{ username: "admin", password: "admin123" }];
const requireAuth = (req, res, next) => req.session.user ? next() : res.redirect("/login");

app.get("/", (req, res) => res.redirect("/dashboard"));
app.get("/login", (req, res) => res.render("login", { error: null }));
app.post("/login", (req, res) => {
  const { username, password } = req.body;
  const ok = USERS.find(u => u.username === username && u.password === password);
  if (!ok) return res.status(401).render("login", { error: "Invalid credentials" });
  req.session.user = { username };
  res.redirect("/dashboard");
});
app.get("/dashboard", requireAuth, (req, res) => res.render("dashboard", { user: req.session.user }));
app.post("/logout", (req, res) => req.session.destroy(() => res.redirect("/login")));

const PORT = process.env.PORT || 3002;
app.listen(PORT, () => console.log(`Q3 running at http://localhost:${PORT}`));
