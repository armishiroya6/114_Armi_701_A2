# Q3 Login with Redis Session Store
Requires a running Redis instance.
- Install Redis locally or use Docker: `docker run -p 6379:6379 redis:alpine`
- Start: `npm i && npm run start`
- Optional env: `REDIS_URL=redis://localhost:6379`
